@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if exist "%LOCALAPPDATA%\Programs\Eclipse-Temurin\jdk-21.0.13+9\bin\java.exe" set "JAVA_HOME=%LOCALAPPDATA%\Programs\Eclipse-Temurin\jdk-21.0.13+9"
set "PATH=%JAVA_HOME%\bin;%LOCALAPPDATA%\Programs\Apache-Maven\apache-maven-3.10.1\bin;%PATH%"
call mvn -q package
if errorlevel 1 goto end
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -cp "target\classes;target\lib\*" kz.university.Main
:end
pause
